public class ScrapperThread {
    
}